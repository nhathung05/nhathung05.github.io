"# Core-remove-kodi" 
